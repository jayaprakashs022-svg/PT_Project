# 🎓 College Complaint Portal

A full-stack web application that allows students to submit complaints to college administration, and lets admins view all submitted complaints in a dashboard.

## 🚀 Features

- Students can submit complaints with name, department, category, and description
- Complaints are stored on the backend (in-memory)
- Admin dashboard to view all complaints in a table
- Clean, responsive UI

## 🛠️ Tech Stack

- **Frontend:** HTML, CSS, JavaScript
- **Backend:** Node.js, Express.js

## 📁 Project Structure

```
college-complaint-app/
├── backend/
│   ├── server.js        # Express server & API routes
│   └── package.json
├── frontend/
│   ├── index.html       # Complaint submission form
│   ├── admin.html       # Admin complaints dashboard
│   ├── script.js        # Form submission logic
│   └── style.css        # Styling
└── README.md
```

## ⚙️ How to Run Locally

1. Clone the repository:
   ```bash
   git clone https://github.com/jayaprakashs022-svg/college-complaint-app.git
   cd college-complaint-app
   ```

2. Install backend dependencies:
   ```bash
   cd backend
   npm install
   ```

3. Start the server:
   ```bash
   node server.js
   ```

4. Open your browser and go to:
   ```
   http://localhost:5000
   ```

## 📋 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/test` | Health check |
| POST | `/api/complaints` | Submit a new complaint |
| GET | `/api/complaints` | Get all complaints |

## 👤 Author

**Jayaprakash S**  
GitHub: [@jayaprakashs022-svg](https://github.com/jayaprakashs022-svg)
