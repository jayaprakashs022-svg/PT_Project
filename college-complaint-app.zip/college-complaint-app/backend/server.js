const express = require("express");
const cors = require("cors");
const path = require("path");

const app = express();
const PORT = 5000;

// In-memory store for complaints
const complaints = [];
let nextId = 1;

app.use(cors());
app.use(express.json());

// Serve the frontend files
app.use(express.static(path.join(__dirname, "../frontend")));

// Health check
app.get("/api/test", (req, res) => {
  res.json({ message: "Server connected successfully!" });
});

// POST /api/complaints — submit a new complaint
app.post("/api/complaints", (req, res) => {
  const { name, department, category, description } = req.body;

  if (!name || !department || !category || !description) {
    return res.status(400).json({ message: "All fields are required" });
  }

  const complaint = {
    id: nextId++,
    name,
    department,
    category,
    description,
    status: "Pending",
    submittedAt: new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata" })
  };

  complaints.push(complaint);
  console.log("Complaint stored:", complaint);

  res.status(201).json({ message: "Complaint submitted successfully!", complaint });
});

// GET /api/complaints — fetch all stored complaints
app.get("/api/complaints", (req, res) => {
  res.json(complaints);
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
