let complaints = [];

app.post("/complaints", async (req, res) => {
  const { studentName, department, complaint } = req.body;

  if (!studentName || !department || !complaint) {
    return res.status(400).json({
      message: "Please fill all fields"
    });
  }

  const newComplaint = {
    id: Date.now(),
    studentName,
    department,
    complaint,
    status: "Pending"
  };

  const db = req.app.locals.db;

const result = await db.collection("complaints").insertOne(newComplaint);

  res.status(201).json({
    message: "Complaint submitted successfully!",
    data: newComplaint
  });
});

app.get("/complaints", (req, res) => {
  res.json(complaints);
});