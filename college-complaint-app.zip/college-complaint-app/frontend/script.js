const form = document.getElementById("complaintForm");
const messageEl = document.getElementById("message");

form.addEventListener("submit", async (event) => {
    event.preventDefault();

    const complaint = {
        name: document.getElementById("studentName").value.trim(),
        department: document.getElementById("department").value.trim(),
        category: document.getElementById("category").value,
        description: document.getElementById("description").value.trim()
    };

    try {
        const response = await fetch("http://localhost:5000/api/complaints", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(complaint)
        });

        const result = await response.json();

        if (!response.ok) {
            throw new Error(result.message || "Submission failed");
        }

        messageEl.textContent = "✅ Complaint submitted successfully!";
        messageEl.className = "success";
        form.reset();

    } catch (error) {
        messageEl.textContent = "❌ " + (error.message === "Failed to fetch"
            ? "Could not connect to the server. Please try again."
            : error.message);
        messageEl.className = "error";
    }
});
