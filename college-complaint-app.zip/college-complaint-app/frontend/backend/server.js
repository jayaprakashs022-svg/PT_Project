const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.send("College Complaint Backend is running!");
});

app.post("/api/complaints", (req, res) => {
  console.log("Complaint received:", req.body);
  res.status(201).json({
    message: "Complaint submitted successfully!"
  });
});

app.listen(5000, () => {
  console.log("Backend running at http://localhost:5000");
});